/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    systemcontrol.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "systemcontrol.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

SYSTEMCONTROL_DATA systemcontrolData;

bool sdMount, sdConfig_read, sdSchedule_read, logReady;
bool z1En, z2En, z3En, z4En;
SYS_FS_HANDLE datalog, config, schedule;
SYS_FS_RESULT mount, drive_set, unmount;
SYS_FS_RESULT datalog_close, config_close, schedule_close;
SYS_FS_ERROR err;
size_t datalog_bytes_written, config_bytes_read, schedule_bytes_read;
size_t config_file_size, schedule_file_size;

QueueHandle_t u1command;
QueueHandle_t u2command;
QueueHandle_t u3command;
QueueHandle_t u4command;
QueueHandle_t u5command;
QueueHandle_t u6command;

QueueHandle_t u1Status;
QueueHandle_t u2Status;
QueueHandle_t u3Status;
QueueHandle_t u4Status;
QueueHandle_t u5Status;
QueueHandle_t u6Status;

QueueHandle_t ccu_command;

char *com = ",";
char *newline = "\n";

char config_buff[500];
char *res[80];
char *config_table[40][2];

char schedule_buff[10000];
char *res2[60];
char *schedule_table [10][6];

char *res3[5];

int lowpoint[500];

int i, j, k, p, q;
uint8_t num_update = 0;
uint8_t num_actions = 0;

uint8_t damper_command, hvac_command;
uint16_t ccu_out_command;
/*  128,64,32,16,8,4,2,1
 * damper_command -> 8 bit masking command to carry damper instructions
 *  D8,D7,D6,D5,D4,D3,D2,D1
 * hvac_command -> 8 bit masking command to carry AHU control line instructions
 *  NULL,H1,H2,C1,C2,F1,F2,F3
 * ccu_out_command -> 16 bit command to send instructions to the output of the CCU
 *  NULL,H1,H2,C1,C2,F1,F2,F3,D8,D7,D6,D5,D4,D3,D2,D1
 */
uint8_t H1 = 64;
uint8_t H2 = 32;
uint8_t C1 = 16;
uint8_t C2 = 8;
uint8_t F1 = 4;
uint8_t F2 = 2;
uint8_t F3 = 1;
uint8_t damper_command, hvac_command;
uint16_t ccu_out_command;

bool u1En, u2En, u3En, u4En;

SENSOR_UNIT_INTERFACE_STATE send_idle = APP_STATE_USART_TX_GREEN;

TIME_PROCESS prep_offset; // prep state time, offset pass to max runtime function
TIME_PROCESS idle_offset; // idle time offset, pass to max runtime function
TIME_PROCESS config_check_offset; // config offset, pass to max runtime function

TIME_PROCESS process_time(char time_in[8]) {
    TIME_PROCESS t;
    int x, hr, min, sec;
    char *time_res[3];
    x = 0;
    time_res[x] = strtok(time_in, ":");
    while (time_res[x] != NULL) {
        time_res[++x] = strtok(NULL, ":");
    }
    hr = atoi(res[0]);
    min = atoi(res[1]);
    sec = atoi(res[2]);
    t.day = SUNDAY;
    t.hour = hr;
    t.minute = min;
    t.second = sec;
    return t;
}

TIME_PROCESS find_max_runtime(TIME_PROCESS offset) {
    TIME_PROCESS max_runtime;

    max_runtime.second = CURRENT_SEC + offset.second;
    if (max_runtime.second > 59) {
        max_runtime.second = max_runtime.second - 59;
        offset.minute++;
    }
    max_runtime.minute = CURRENT_MIN + offset.minute;
    if (max_runtime.minute > 59) {
        max_runtime.minute = max_runtime.minute - 59;
        offset.hour++;
    }
    max_runtime.hour = CURRENT_HOUR + offset.hour;
    if (max_runtime.hour > 23) {
        max_runtime.hour = max_runtime.hour - 23;
        offset.day++;
    }
    max_runtime.day = CURRENT_DAY + offset.day;
    if (max_runtime.day > SATURDAY) {
        max_runtime.day = max_runtime.day - SATURDAY;
    }

    return max_runtime;
}

bool runtime_check(TIME_PROCESS time) {
    if (CURRENT_DAY > time.day) {
        return true;
    } else if (CURRENT_DAY == time.day) {
        if (CURRENT_HOUR > time.hour) {
            return true;
        } else if (CURRENT_HOUR == time.hour) {
            if (CURRENT_MIN > time.minute) {
                return true;
            } else if (CURRENT_MIN == time.minute) {
                if (CURRENT_SEC > time.second) {
                    return true;
                }
            }
        }
    }
    return false;
}



// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

bool mountsd() {
    mount = SYS_FS_Mount("/dev/mmcblka1", "/mnt/myDrive", FAT, 0, NULL);
    if (mount == 0) {
        BSP_LEDOn(LED3);
        drive_set = SYS_FS_CurrentDriveSet("/mnt/myDrive");
        err = SYS_FS_Error();
        Nop();
        return true;
    } else {
        err = SYS_FS_Error();
        BSP_LEDToggle(LED3);
        Nop();
        return false;
    }
}

void check_config() {
    while (1) {
        switch (systemcontrolData.sdstate) {
            case SYSTEMCONTROL_STATE_READ_CONFIG:
                BSP_LEDOn(LED3);
                logReady = false;
                config = SYS_FS_FileOpen("config.csv", (SYS_FS_FILE_OPEN_READ));
                if (config == SYS_FS_HANDLE_INVALID) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_file_size = SYS_FS_FileSize(config);
                if (config_file_size == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_bytes_read = SYS_FS_FileRead(config, config_buff, config_file_size);
                if (config_bytes_read == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                config_close = SYS_FS_FileClose(config);
                if (config_close == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                if (err != SYS_FS_ERROR_OK) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                systemcontrolData.sdstate = SYSTEMCONTROL_STATE_PROCESS_CONFIG;
                BSP_LEDOff(LED3);
                Nop();

                break;

            case SYSTEMCONTROL_STATE_PROCESS_CONFIG:
                Nop();
                // break file into tokens based on comma and newline
                res[i] = strtok(config_buff, "\n,");
                while (res[i] != NULL) {
                    res[++i] = strtok(NULL, "\n,");
                }

                // build a table so that information can be processed by eliminating
                // the left column from the file
                for (j = 0; j <= 40; j++) {
                    config_table[j][0] = res[2 * j];
                    config_table[j][1] = res[2 * j + 1];
                }
                Nop();

                for (i = 0; i < 4; i++) { // read zone info
                    // check if a zone is active
                    j = atoi(config_table[i + 1][1]);
                    systemcontrolData.config.zone[i] = j;
                }
                for (i = 0; i < 8; i++) { // read damper info
                    // check if damper is active and normally open or closed
                    j = atoi(config_table[i + 5][1]);
                    systemcontrolData.config.damper[i] = j;
                }
                for (i = 0; i < 8; i++) { // read damper in zone info
                    // check what zone a damper sends air to
                    j = atoi(config_table[i + 13][1]);
                    systemcontrolData.config.damper_in_zone[i] = j;
                }
                for (i = 0; i < 8; i++) { // read airflow mode
                    j = atoi(config_table[i + 21][1]);
                    systemcontrolData.config.damper_mode[i] = j;
                }
                i = 29;
                systemcontrolData.config.ahu.cSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.cAnt, config_table[i++][1]);
                systemcontrolData.config.ahu.coolAnt = process_time(systemcontrolData.config.ahu.cAnt);
                strcpy(systemcontrolData.config.ahu.cRunT, config_table[i++][1]);
                systemcontrolData.config.ahu.coolRunT = process_time(systemcontrolData.config.ahu.cRunT);
                strcpy(systemcontrolData.config.ahu.cCycleT, config_table[i++][1]);
                systemcontrolData.config.ahu.coolCycleT = process_time(systemcontrolData.config.ahu.cCycleT);
                systemcontrolData.config.ahu.hSys = atoi(config_table[i++][1]);
                strcpy(systemcontrolData.config.ahu.hAnt, config_table[i++][1]);
                systemcontrolData.config.ahu.heatAnt = process_time(systemcontrolData.config.ahu.hAnt);
                strcpy(systemcontrolData.config.ahu.hRunT, config_table[i++][1]);
                systemcontrolData.config.ahu.heatRunT = process_time(systemcontrolData.config.ahu.hRunT);
                strcpy(systemcontrolData.config.ahu.hCycleT, config_table[i++][1]);
                systemcontrolData.config.ahu.heatCycleT = process_time(systemcontrolData.config.ahu.hCycleT);
                systemcontrolData.config.ahu.overTemp = atoi(config_table[i++][1]);

                Nop();
                systemcontrolData.sdstate = SYSTEMCONTROL_STATE_APPLY_CONFIG;

                break;
            case SYSTEMCONTROL_STATE_APPLY_CONFIG:
                // if zone is enabled, then generate damper commands tied to it
                // commands such as sending or blocking air and sending warm or cool air
                i = 0;
                if (systemcontrolData.config.zone[i]) {
                    // zone 1 
                    z1En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone1.dampers = systemcontrolData.zone1.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone1.cut_air_command = systemcontrolData.zone1.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone1.allow_air_command = systemcontrolData.zone1.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone1.send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone1.allow_air_command;
                                systemcontrolData.zone1.send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone1.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone1.send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone1.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone1.send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone1.cut_air_command;
                            }
                        }
                    }
                } else {
                    z1En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 2 
                    z2En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone2.dampers = systemcontrolData.zone2.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone2.cut_air_command = systemcontrolData.zone2.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone2.allow_air_command = systemcontrolData.zone2.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone2.send_heat = systemcontrolData.zone2.send_heat | systemcontrolData.zone2.allow_air_command;
                                systemcontrolData.zone2.send_cool = systemcontrolData.zone2.send_cool | systemcontrolData.zone2.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone2.send_heat = systemcontrolData.zone2.send_heat | systemcontrolData.zone2.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone2.send_cool = systemcontrolData.zone2.send_cool | systemcontrolData.zone2.cut_air_command;
                            }
                        }
                    }
                } else {
                    z2En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 3 
                    z3En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone3.dampers = systemcontrolData.zone3.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone3.cut_air_command = systemcontrolData.zone3.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone3.allow_air_command = systemcontrolData.zone3.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone3.send_heat = systemcontrolData.zone3.send_heat | systemcontrolData.zone3.allow_air_command;
                                systemcontrolData.zone3.send_cool = systemcontrolData.zone3.send_cool | systemcontrolData.zone3.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone3.send_heat = systemcontrolData.zone3.send_heat | systemcontrolData.zone3.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone3.send_cool = systemcontrolData.zone3.send_cool | systemcontrolData.zone3.cut_air_command;
                            }
                        }
                    }
                } else {
                    z3En = false;
                }
                i++;
                if (systemcontrolData.config.zone[i]) {
                    // zone 4 
                    z4En = true;
                    for (j = 0; j < 8; j++) {
                        k = 1;
                        if ((systemcontrolData.config.damper[j] >= 1) && (systemcontrolData.config.damper_in_zone[j] == (i + 1))) {
                            k = k << j;
                            systemcontrolData.zone4.dampers = systemcontrolData.zone4.dampers | (k);
                            if (systemcontrolData.config.damper[j] == 1) {
                                systemcontrolData.zone4.cut_air_command = systemcontrolData.zone4.cut_air_command | (k);
                            } else if (systemcontrolData.config.damper[j] == 2) {
                                systemcontrolData.zone4.allow_air_command = systemcontrolData.zone4.allow_air_command | (k);
                            }

                            if ((systemcontrolData.config.damper_mode[j] == 0)) {
                                systemcontrolData.zone4.send_heat = systemcontrolData.zone4.send_heat | systemcontrolData.zone4.allow_air_command;
                                systemcontrolData.zone4.send_cool = systemcontrolData.zone4.send_cool | systemcontrolData.zone4.allow_air_command;
                            } else if ((systemcontrolData.config.damper_mode[j] == 1)) {
                                systemcontrolData.zone4.send_heat = systemcontrolData.zone4.send_heat | systemcontrolData.zone4.cut_air_command;
                            } else if (systemcontrolData.config.damper_mode[j] == 2) {
                                systemcontrolData.zone4.send_cool = systemcontrolData.zone4.send_cool | systemcontrolData.zone4.cut_air_command;
                            }
                        }
                    }
                } else {
                    z4En = false;
                }
                i++;


                int all_active_dampers = systemcontrolData.zone1.dampers | systemcontrolData.zone2.dampers | systemcontrolData.zone3.dampers | systemcontrolData.zone4.dampers;
                int all_allow_air = systemcontrolData.zone1.allow_air_command | systemcontrolData.zone2.allow_air_command | systemcontrolData.zone3.allow_air_command | systemcontrolData.zone4.allow_air_command;
                int all_block_air = systemcontrolData.zone1.cut_air_command | systemcontrolData.zone2.cut_air_command | systemcontrolData.zone3.cut_air_command | systemcontrolData.zone4.cut_air_command;
                int all_send_heat = systemcontrolData.zone1.send_heat | systemcontrolData.zone2.send_heat | systemcontrolData.zone3.send_heat | systemcontrolData.zone4.send_heat;
                int all_send_cool = systemcontrolData.zone1.send_cool | systemcontrolData.zone2.send_cool | systemcontrolData.zone3.send_cool | systemcontrolData.zone4.send_cool;

                //                while (BSP_SwitchStateGet(B1)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_active_dampers & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_active_dampers & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B2)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_allow_air & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_allow_air & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B3)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_block_air & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_block_air & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B4)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_send_heat & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_send_heat & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();
                //
                //                while (BSP_SwitchStateGet(B5)) {
                //                    i = 1;
                //                    BSP_LEDStateSet(D1_EN, (all_send_cool & 1));
                //                    BSP_LEDStateSet(D2_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D3_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D4_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D5_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D6_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D7_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                    BSP_LEDStateSet(D8_EN, (all_send_cool & 1 << i) >> i);
                //                    i++;
                //                }
                //                Nop();

                systemcontrolData.sdstate = SYSTEMCONTROL_STATE_READ_SCHEDULE;
                Nop();
                sdConfig_read = true;
                break;

            case SYSTEMCONTROL_STATE_READ_SCHEDULE:
                BSP_LEDOn(LED3);
                // need to work with bret on doing a switch case for choosing a schedule based on user input

                schedule = SYS_FS_FileOpen("schedule.csv", (SYS_FS_FILE_OPEN_READ));
                if (schedule == SYS_FS_HANDLE_INVALID) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_file_size = SYS_FS_FileSize(schedule);
                if (schedule_file_size == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_bytes_read = SYS_FS_FileRead(schedule, schedule_buff, schedule_file_size);
                if (schedule_bytes_read == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                schedule_close = SYS_FS_FileClose(schedule);
                if (schedule_close == -1) {
                    BSP_LEDOn(LED2);
                    Nop();
                }
                err = SYS_FS_Error();
                if (err != SYS_FS_ERROR_OK) {
                    BSP_LEDOn(LED2);
                    Nop();
                }

                systemcontrolData.sdstate = SYSTEMCONTROL_STATE_PROCESS_SCHEDULE;
                BSP_LEDOff(LED3);
                sdConfig_read = true;
                Nop();
                break;

            case SYSTEMCONTROL_STATE_PROCESS_SCHEDULE:
                i = 0;
                res2[i] = strtok(schedule_buff, "\n,");
                while (res2[i] != NULL) {
                    res2[++i] = strtok(NULL, "\n,");
                }

                for (j = 0; j <= 10; j++) {
                    schedule_table[j][0] = res2[6 * j];
                    schedule_table[j][1] = res2[6 * j + 1];
                    schedule_table[j][2] = res2[6 * j + 2];
                    schedule_table[j][3] = res2[6 * j + 3];
                    schedule_table[j][4] = res2[6 * j + 4];
                    schedule_table[j][5] = res2[6 * j + 5];
                }

                for (i = 0; i < 4; i++) { // read zone info
                    j = atoi(config_table[i + 1][4]);
                    k = atoi(schedule_table[i + 1][5]);
                    systemcontrolData.zL[i] = j;
                    systemcontrolData.zH[i] = k;
                }
                systemcontrolData.sdstate = SYSTEMCONTROL_GET_DATA;
                sdSchedule_read = true;
                logReady = true;
                return;
                break;
        }
    }
}

/*******************************************************************************
  Function:
    void SYSTEMCONTROL_Initialize ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

void SYSTEMCONTROL_Initialize(void) {
    /* Place the App state machine in its initial state. */

    /* TODO: Initialize your application's state machine and other
     * parameters.
     */

    u1command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u2command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u3command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u4command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u5command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));
    u6command = xQueueCreate(2, sizeof (SENSOR_UNIT_INTERFACE_STATE));

    u1Status = xQueueCreate(4, sizeof (uint32_t));
    u2Status = xQueueCreate(4, sizeof (uint32_t));
    u3Status = xQueueCreate(4, sizeof (uint32_t));
    u4Status = xQueueCreate(4, sizeof (uint32_t));
    u5Status = xQueueCreate(4, sizeof (uint32_t));
    u6Status = xQueueCreate(4, sizeof (uint32_t));

    ccu_command = xQueueCreate(2, sizeof (ccu_out_command));

    systemcontrolData.hvac_nextstate = HVAC_BOOTUP;
    //    default_prep_time.minute = 1;
    //    default_prep_time.second = 15;
    //    default_idle_time.minute = 5;

    prep_offset.day = prep_day_offset;
    prep_offset.hour = prep_hour_offset;
    prep_offset.minute = prep_min_offset;
    prep_offset.second = prep_sec_offset;

    idle_offset.day = idle_day_offset;
    idle_offset.hour = idle_hour_offset;
    idle_offset.minute = idle_min_offset;
    idle_offset.second = idle_sec_offset;

    config_check_offset.day = config_day_offset;
    config_check_offset.hour = config_hour_offset;
    config_check_offset.minute = config_min_offset;
    config_check_offset.second = config_sec_offset;
}

/******************************************************************************
  Function:
    void SYSTEMCONTROL_Tasks ( void )

  Remarks:
    See prototype in systemcontrol.h.
 */

void SYSTEMCONTROL_Tasks(void) {
    while (1) {
        switch (systemcontrolData.hvac_nextstate) {
            case HVAC_READY:
                systemcontrolData.hvac_currentstate = HVAC_READY;
                break;

            case HVAC_IDLE:
                if (systemcontrolData.hvac_currentstate != HVAC_IDLE) {
                    systemcontrolData.hvac_currentstate = HVAC_IDLE;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(idle_offset);
                }
                damper_command = systemcontrolData.zone1.allow_air_command | systemcontrolData.zone2.allow_air_command | systemcontrolData.zone3.allow_air_command | systemcontrolData.zone4.allow_air_command;
                hvac_command = 0;
                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_READY;
                    systemcontrolData.hvac_prevstate = HVAC_IDLE;
                }
                break;

            case HVAC_COOL_PREP:
                if (systemcontrolData.hvac_currentstate != HVAC_IDLE) {
                    systemcontrolData.hvac_currentstate = HVAC_COOL_PREP;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(prep_offset);
                }
                i = 0;
                damper_command = 0;
                if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone1.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone1.cut_air_command;
                }
                if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone2.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone2.cut_air_command;
                }
                if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone3.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone3.cut_air_command;
                }
                if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone4.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone4.cut_air_command;
                }

                if (i == 1) {
                    hvac_command |= F1; // fan speed  
                } else if ((i == 2) || (i == 3)) {
                    hvac_command |= F2; // fan speed 2
                } else if (i == 4) {
                    hvac_command |= F3; // fan speed 3
                } else {
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOLING;
                    systemcontrolData.hvac_prevstate = HVAC_COOL_PREP;
                }
                break;

            case HVAC_COOLING:
                i = 0;
                damper_command = 0;
                if (systemcontrolData.hvac_currentstate != HVAC_COOLING) {
                    systemcontrolData.hvac_currentstate = HVAC_COOLING;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(systemcontrolData.config.ahu.coolRunT);
                }

                if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone1.send_cool;
                } else if ((systemcontrolData.z2.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_COOL)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_COOLING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone1.cut_air_command;
                    i--;
                }

                if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone2.send_cool;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_COOL)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_COOLING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone2.cut_air_command;
                    i--;
                }
                if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone3.send_cool;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z2.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_COOL)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_COOLING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone3.cut_air_command;
                    i--;
                }

                if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_COOL) {
                    i++;
                    damper_command |= systemcontrolData.zone4.send_cool;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z2.zone_needs_mode != ZONE_NEED_COOL) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_COOL)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_COOLING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone4.cut_air_command;
                    i--;
                }

                if (i == 1) {
                    hvac_command |= F1; // fan speed
                    hvac_command |= C1;
                } else if ((i == 2) || (i == 3)) {
                    hvac_command |= F2; // fan speed 2
                    hvac_command |= C1;
                } else if (i == 4) {
                    hvac_command |= F3; // fan speed 3
                    hvac_command |= C2;
                } else {
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_COOLING;
                }
                break;

            case HVAC_COOL_DOWN:
                if (systemcontrolData.hvac_currentstate != HVAC_COOL_DOWN) {
                    systemcontrolData.hvac_currentstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(systemcontrolData.config.ahu.coolCycleT);
                    i = 0;
                    i = C1 | C2;
                    i = hvac_command & i;
                    hvac_command = hvac_command ^ i;
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_IDLE;
                    systemcontrolData.hvac_prevstate = HVAC_COOL_DOWN;
                }

                break;

            case HVAC_HEAT_PREP:
                if (systemcontrolData.hvac_currentstate != HVAC_IDLE) {
                    systemcontrolData.hvac_currentstate = HVAC_HEAT_PREP;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(prep_offset);
                }
                i = 0;
                damper_command = 0;
                if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone1.send_heat;
                } else {
                    damper_command |= systemcontrolData.zone1.cut_air_command;
                }
                if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone2.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone2.cut_air_command;
                }
                if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone3.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone3.cut_air_command;
                }
                if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone4.send_cool;
                } else {
                    damper_command |= systemcontrolData.zone4.cut_air_command;
                }

                if (i == 1) {
                    hvac_command |= F1; // fan speed  
                } else if ((i == 2) || (i == 3)) {
                    hvac_command |= F2; // fan speed 2
                } else if (i == 4) {
                    hvac_command |= F3; // fan speed 3
                } else {
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEATING;
                    systemcontrolData.hvac_prevstate = HVAC_HEAT_PREP;
                }
                break;

            case HVAC_HEATING:
                i = 0;
                damper_command = 0;
                if (systemcontrolData.hvac_currentstate != HVAC_HEATING) {
                    systemcontrolData.hvac_currentstate = HVAC_HEATING;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(systemcontrolData.config.ahu.heatRunT);
                }
                if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone1.send_heat;
                } else if ((systemcontrolData.z2.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_HEAT)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEAT_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_HEATING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone1.cut_air_command;
                    i--;
                }

                if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone2.send_heat;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_HEAT)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEAT_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_HEATING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone2.cut_air_command;
                    i--;
                }
                if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone3.send_heat;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z2.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z4.zone_needs_mode != ZONE_NEED_HEAT)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEAT_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_HEATING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone3.cut_air_command;
                    i--;
                }

                if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_HEAT) {
                    i++;
                    damper_command |= systemcontrolData.zone4.send_heat;
                } else if ((systemcontrolData.z1.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z2.zone_needs_mode != ZONE_NEED_HEAT) && (systemcontrolData.z3.zone_needs_mode != ZONE_NEED_HEAT)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEAT_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_HEATING;
                    break;
                } else {
                    damper_command |= systemcontrolData.zone4.cut_air_command;
                    i--;
                }

                if (i == 1) {
                    hvac_command |= F1; // fan speed
                    hvac_command |= H1;
                } else if ((i == 2) || (i == 3)) {
                    hvac_command |= F2; // fan speed 2
                    hvac_command |= H1;
                } else if (i == 4) {
                    hvac_command |= F3; // fan speed 3
                    hvac_command |= H2;
                } else {
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_HEAT_DOWN;
                    systemcontrolData.hvac_prevstate = HVAC_HEATING;
                }
                break;

            case HVAC_HEAT_DOWN:
                if (systemcontrolData.hvac_currentstate != HVAC_COOL_DOWN) {
                    systemcontrolData.hvac_currentstate = HVAC_COOL_DOWN;
                    systemcontrolData.hvac_statechange_time = find_max_runtime(systemcontrolData.config.ahu.coolCycleT);
                    i = 0;
                    i = H1 | H2;
                    i = hvac_command & i;
                    hvac_command = hvac_command ^ i;
                    Nop();
                }

                if (runtime_check(systemcontrolData.hvac_statechange_time)) {
                    systemcontrolData.hvac_nextstate = HVAC_IDLE;
                    systemcontrolData.hvac_prevstate = HVAC_HEAT_DOWN;
                }
                break;
            case HVAC_BOOTUP:
                sdMount = mountsd();
                if (sdMount) {
                    check_config();
                    systemcontrolData.hvac_nextstate = HVAC_IDLE;
                } else {
                    systemcontrolData.hvac_currentstate = HVAC_BOOTUP;
                    systemcontrolData.hvac_nextstate = HVAC_BOOTUP;
                }
                break;
            case HVAC_SETUP_CHECK:
                systemcontrolData.hvac_currentstate = HVAC_SETUP_CHECK;
                logReady = false;
                check_config();
                logReady = true;
                systemcontrolData.hvac_nextstate = HVAC_READY;
                break;
        }



        if (uxQueueMessagesWaiting(u1Status)) {
            xQueueReceive(u1Status, &systemcontrolData.z1.status.temperatureF, 10);
            if ((systemcontrolData.z1.status.temperatureF < systemcontrolData.zL[0]) && z1En) {
                systemcontrolData.z1.zone_needs_mode = ZONE_NEED_HEAT;
            } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[0]) && z1En) {
                systemcontrolData.z1.zone_needs_mode = ZONE_NEED_COOL;
            } else {
                systemcontrolData.z1.zone_needs_mode = ZONE_IDLE;
            }
        }
        if (uxQueueMessagesWaiting(u2Status)) {
            xQueueReceive(u2Status, &systemcontrolData.z2.status.temperatureF, 10);
            if ((systemcontrolData.z2.status.temperatureF < systemcontrolData.zL[1]) && z2En) {
                systemcontrolData.z2.zone_needs_mode = ZONE_NEED_HEAT;
            } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[1]) && z2En) {
                systemcontrolData.z2.zone_needs_mode = ZONE_NEED_COOL;
            } else {
                systemcontrolData.z2.zone_needs_mode = ZONE_IDLE;
            }
        }
        if (uxQueueMessagesWaiting(u3Status)) {
            xQueueReceive(u3Status, &systemcontrolData.z3.status.temperatureF, 10);
            if ((systemcontrolData.z3.status.temperatureF < systemcontrolData.zL[2]) && z3En) {
                systemcontrolData.z3.zone_needs_mode = ZONE_NEED_HEAT;
            } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[2]) && z3En) {
                systemcontrolData.z3.zone_needs_mode = ZONE_NEED_COOL;
            } else {
                systemcontrolData.z3.zone_needs_mode = ZONE_IDLE;
            }
        }
        if (uxQueueMessagesWaiting(u4Status)) {
            xQueueReceive(u4Status, &systemcontrolData.z4.status.temperatureF, 10);
            if ((systemcontrolData.z4.status.temperatureF < systemcontrolData.zL[3]) && z4En) {
                systemcontrolData.z4.zone_needs_mode = ZONE_NEED_HEAT;
            } else if ((systemcontrolData.z1.status.temperatureF > systemcontrolData.zH[3]) && z4En) {
                systemcontrolData.z4.zone_needs_mode = ZONE_NEED_COOL;
            } else {
                systemcontrolData.z4.zone_needs_mode = ZONE_IDLE;
            }
        }
        if (uxQueueMessagesWaiting(u5Status)) {
            xQueueReceive(u5Status, &systemcontrolData.e1.status.temperatureF, 10);

        }
        if (uxQueueMessagesWaiting(u6Status)) {
            xQueueReceive(u6Status, &systemcontrolData.e2.status.temperatureF, 10);

        }

        if (systemcontrolData.hvac_currentstate == HVAC_READY) {
            systemcontrolData.needCool = 0;
            systemcontrolData.needHeat = 0;
            if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_COOL) {
                systemcontrolData.needCool++;
            } else if (systemcontrolData.z1.zone_needs_mode == ZONE_NEED_HEAT) {
                systemcontrolData.needHeat++;
            }
            if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_COOL) {
                systemcontrolData.needCool++;
            } else if (systemcontrolData.z2.zone_needs_mode == ZONE_NEED_HEAT) {
                systemcontrolData.needHeat++;
            }
            if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_COOL) {
                systemcontrolData.needCool++;
            } else if (systemcontrolData.z3.zone_needs_mode == ZONE_NEED_HEAT) {
                systemcontrolData.needHeat++;
            }
            if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_COOL) {
                systemcontrolData.needCool++;
            } else if (systemcontrolData.z4.zone_needs_mode == ZONE_NEED_HEAT) {
                systemcontrolData.needHeat++;
            }

            if (systemcontrolData.needCool >= systemcontrolData.needHeat) {
                systemcontrolData.hvac_prevstate = HVAC_READY;
                systemcontrolData.hvac_nextstate = HVAC_COOL_PREP;
            } else if (systemcontrolData.needHeat > systemcontrolData.needCool) {
                systemcontrolData.hvac_prevstate = HVAC_READY;
                systemcontrolData.hvac_nextstate = HVAC_HEAT_PREP;
            }
        }

        if ((systemcontrolData.hvac_currentstate == HVAC_READY)&&(runtime_check(systemcontrolData.config_check_time))) {
            systemcontrolData.hvac_nextstate = HVAC_SETUP_CHECK;
        }
        
        ccu_out_command = (hvac_command << 8) | damper_command;
        xQueueSend(ccu_command, &ccu_out_command, 10);
        vTaskDelay(100);
    }
}



/*******************************************************************************
 End of File
 */
