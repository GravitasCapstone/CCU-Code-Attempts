/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    u3.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "u3.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

U3_DATA u3Data;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void U3_Initialize ( void )

  Remarks:
    See prototype in u3.h.
 */



void U3_Initialize(void) {
    u3Data.prevstate = APP_STATE_USART_INIT;
    u3Data.handle = DRV_USART_Open(DRV_USART_INDEX_2, DRV_IO_INTENT_READWRITE);
    if (u3Data.handle == DRV_HANDLE_INVALID) {
        u3Data.error = USART_OPEN_FAIL;
    } else {
        u3Data.nextstate = APP_STATE_USART_TX_GREEN;
        u3Data.error = NO_ERROR;
        BSP_LEDStateSet(U3_EN, 0);
    }
    u3Data.data_ptr = &u3Data.zonedata;
}

/******************************************************************************
  Function:
    void U3_Tasks ( void )

  Remarks:
    See prototype in u3.h.
 */
void U3_Tasks(void) {
    while (1) {
        if ((u3Data.error == NO_ERROR) && (sdReady == true) && (z3En == true)) {
            switch (u3Data.nextstate) {
                case APP_STATE_USART_TX:
                    // set 485 to TX
                    BSP_LEDStateSet(U3_EN, 1);
                    // send data
                    DRV_USART_Write(u3Data.handle, &u3Data.command, sizeof (u3Data.command));
                    u3Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u3Data.nextstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                    vTaskDelay(10);
                    break;
                case APP_STATE_USART_WAIT_FOR_TX_COMPLETION:
                    if (DRV_USART_TRANSFER_STATUS_TRANSMIT_EMPTY & DRV_USART_TransferStatus(u3Data.handle)) {
                        // TX complete and prep for RX
                        BSP_LEDStateSet(U3_EN, 0);
                        u3Data.prevstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                        u3Data.nextstate = APP_STATE_USART_IDLE;
                    }
                    break;
                case APP_STATE_USART_RX:
                    DRV_USART_Read(u3Data.handle, &u3Data.data.rec[0], 4);
                    u3Data.prevstate = APP_STATE_USART_RX;
                    u3Data.nextstate = APP_STATE_DATA_DECODE;
                    Nop();
                    vTaskDelay(10);
                    break;
                case APP_STATE_DATA_DECODE:
                    u3Data.data.temp_bytes[0] = u3Data.data.rec[0];
                    u3Data.data.temp_bytes[1] = u3Data.data.rec[1];

                    u3Data.data.temp_raw = (unsigned int) (u3Data.data.temp_bytes[1] << 8 | u3Data.data.temp_bytes[0]);

                    u3Data.data.temp_Celcius = ((u3Data.data.temp_raw * 165) / 65536) - 40;
                    u3Data.data.temp_Fahrenheit = u3Data.data.temp_Celcius * 9 / 5 + 32;

                    u3Data.data.humid_bytes[0] = u3Data.data.rec[2];
                    u3Data.data.humid_bytes[1] = u3Data.data.rec[3];

                    u3Data.data.humid_raw = (u3Data.data.humid_bytes[1] << 8 | u3Data.data.humid_bytes[0]);

                    u3Data.data.humid = u3Data.data.humid_raw * 100 / 65536;

                    u3Data.zonedata.date = CURRENT_TIME;
                    u3Data.zonedata.zone = 3;
                    u3Data.zonedata.temperatureC = u3Data.data.temp_Celcius;
                    u3Data.zonedata.temperatureF = u3Data.data.temp_Fahrenheit;
                    u3Data.zonedata.humidity = u3Data.data.humid;
                    u3Data.zonedata.pressure = 0;

                    Nop();
                    xQueueSend(dataQueue, u3Data.data_ptr, 10);
                    xQueueSend(u3Status, &u3Data.zonedata.temperatureF, 10);
                    u3Data.data_repeat = 0;
                    Nop();

                    u3Data.prevstate = APP_STATE_DATA_DECODE;
                    u3Data.nextstate = APP_STATE_USART_IDLE;
                    break;

                case APP_STATE_USART_TX_DATA_REQ:
                    u3Data.command = DATA_REQ;
                    u3Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u3Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_RED:
                    u3Data.command = HEATING;
                    u3Data.prevstate = APP_STATE_USART_TX_RED;
                    u3Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_GREEN:
                    u3Data.command = IDLE;
                    u3Data.prevstate = APP_STATE_USART_TX_GREEN;
                    u3Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_BLUE:
                    u3Data.command = COOLING;
                    u3Data.prevstate = APP_STATE_USART_TX_BLUE;
                    u3Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_IDLE:
                    if (DRV_USART_TRANSFER_STATUS_RECEIVER_DATA_PRESENT & DRV_USART_TransferStatus(u3Data.handle)) {
                        // Input detected
                        u3Data.nextstate = APP_STATE_USART_RX;
                    } else if (uxQueueMessagesWaiting(u3command) && (u3Data.data_repeat > 50)) {
                        // if system command in waiting, read it to change state 
                        xQueueReceive(u3command, &u3Data.sys_command, 20);
                        u3Data.nextstate = u3Data.sys_command;
                        u3Data.data_repeat = 0;
                    } else {
                        u3Data.data_repeat++;
                        if (u3Data.data_repeat >= 100) {
                            u3Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
                            u3Data.data_repeat = 0;
                        } else {
                            u3Data.nextstate = APP_STATE_USART_IDLE;
                        }
                    }
                    u3Data.prevstate = APP_STATE_USART_IDLE;
                    vTaskDelay(50);
                    break;

                default:
                    u3Data.nextstate = APP_STATE_USART_IDLE;
                    break;

            }
            vTaskDelay(10);
            Nop();
        } else if(sdReady == false) {
            vTaskDelay(1000);
        } else{
            // Error Processing
            U3_Initialize();
            vTaskDelay(100);
        }
    }
}



/*******************************************************************************
 End of File
 */
