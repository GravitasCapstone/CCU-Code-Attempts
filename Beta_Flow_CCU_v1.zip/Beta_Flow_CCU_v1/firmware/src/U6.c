/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    u6.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "u6.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
 */

U6_DATA u6Data;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
 */

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void U6_Initialize ( void )

  Remarks:
    See prototype in u6.h.
 */




void U6_Initialize(void) {
    u6Data.prevstate = APP_STATE_USART_INIT;
    u6Data.handle = DRV_USART_Open(DRV_USART_INDEX_5, DRV_IO_INTENT_READWRITE);
    if (u6Data.handle == DRV_HANDLE_INVALID) {
        u6Data.error = USART_OPEN_FAIL;
    } else {
        u6Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
        u6Data.error = NO_ERROR;
        BSP_LEDStateSet(U6_EN, 0);
    }
    u6Data.data_ptr = &u6Data.zonedata;
}

/******************************************************************************
  Function:
    void U6_Tasks ( void )

  Remarks:
    See prototype in u6.h.
 */
void U6_Tasks(void) {
    while (1) {
        if ((u6Data.error == NO_ERROR) && ((sdMount && sdConfig_read && sdSchedule_read) == true)) {
            switch (u6Data.nextstate) {
                case APP_STATE_USART_TX:
                    // set 485 to TX
                    BSP_LEDStateSet(U6_EN, 1);
                    // send data
                    DRV_USART_Write(u6Data.handle, &u6Data.command, sizeof (u6Data.command));
                    u6Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u6Data.nextstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                    vTaskDelay(10);
                    break;
                case APP_STATE_USART_WAIT_FOR_TX_COMPLETION:
                    if (DRV_USART_TRANSFER_STATUS_TRANSMIT_EMPTY & DRV_USART_TransferStatus(u6Data.handle)) {
                        // TX complete and prep for RX
                        BSP_LEDStateSet(U6_EN, 0);
                        u6Data.prevstate = APP_STATE_USART_WAIT_FOR_TX_COMPLETION;
                        u6Data.nextstate = APP_STATE_USART_IDLE;
                    }
                    break;
                case APP_STATE_USART_RX:
                    DRV_USART_Read(u6Data.handle, &u6Data.data.rec[0], 4);
                    u6Data.prevstate = APP_STATE_USART_RX;
                    u6Data.nextstate = APP_STATE_DATA_DECODE;
                    Nop();
                    vTaskDelay(10);
                    break;
                case APP_STATE_DATA_DECODE:
                    u6Data.data.temp_bytes[0] = u6Data.data.rec[0];
                    u6Data.data.temp_bytes[1] = u6Data.data.rec[1];

                    u6Data.data.temp_raw = (unsigned int) (u6Data.data.temp_bytes[1] << 8 | u6Data.data.temp_bytes[0]);

                    u6Data.data.temp_Celcius = ((u6Data.data.temp_raw * 165) / 65536) - 40;
                    u6Data.data.temp_Fahrenheit = u6Data.data.temp_Celcius * 9 / 5 + 32;

                    u6Data.data.humid_bytes[0] = u6Data.data.rec[2];
                    u6Data.data.humid_bytes[1] = u6Data.data.rec[3];

                    u6Data.data.humid_raw = (u6Data.data.humid_bytes[1] << 8 | u6Data.data.humid_bytes[0]);

                    u6Data.data.humid = u6Data.data.humid_raw * 100 / 65536;

                    u6Data.zonedata.pulse = heartbeat;
                    u6Data.zonedata.zone = 1;
                    u6Data.zonedata.temperatureC = u6Data.data.temp_Celcius;
                    u6Data.zonedata.temperatureF = u6Data.data.temp_Fahrenheit;
                    u6Data.zonedata.humidity = u6Data.data.humid;
                    u6Data.zonedata.pressure = 0;

                    Nop();
                    xQueueSend(dataQueue, u6Data.data_ptr, 10);
                    xQueueSend(u6Status, &u6Data.zonedata.temperatureF, 10);
                    u6Data.data_repeat = 0;
                    Nop();

                    u6Data.prevstate = APP_STATE_DATA_DECODE;
                    u6Data.nextstate = APP_STATE_USART_IDLE;
                    break;

                case APP_STATE_USART_TX_DATA_REQ:
                    u6Data.command = DATA_REQ;
                    u6Data.prevstate = APP_STATE_USART_TX_DATA_REQ;
                    u6Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_RED:
                    u6Data.command = HEATING;
                    u6Data.prevstate = APP_STATE_USART_TX_RED;
                    u6Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_GREEN:
                    u6Data.command = IDLE;
                    u6Data.prevstate = APP_STATE_USART_TX_GREEN;
                    u6Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_TX_BLUE:
                    u6Data.command = COOLING;
                    u6Data.prevstate = APP_STATE_USART_TX_BLUE;
                    u6Data.nextstate = APP_STATE_USART_TX;
                    break;

                case APP_STATE_USART_IDLE:
                    if (DRV_USART_TRANSFER_STATUS_RECEIVER_DATA_PRESENT & DRV_USART_TransferStatus(u6Data.handle)) {
                        // Input detected
                        u6Data.nextstate = APP_STATE_USART_RX;
                    } else if (uxQueueMessagesWaiting(u6command)) {
                        // if system command in waitng, read it to change state 
                        xQueueReceive(u6command, &u6Data.sys_command, 20);
                        u6Data.nextstate = u6Data.sys_command;
                        u6Data.data_repeat = 0;
                    } else {
                        u6Data.data_repeat++;
                        if (u6Data.data_repeat >= 100) {
                            u6Data.nextstate = APP_STATE_USART_TX_DATA_REQ;
                            u6Data.data_repeat = 0;
                        } else {
                            u6Data.nextstate = APP_STATE_USART_IDLE;
                        }
                    }
                    u6Data.prevstate = APP_STATE_USART_IDLE;
                    vTaskDelay(50);
                    break;

                default:
                    u6Data.nextstate = APP_STATE_USART_IDLE;
                    break;

            }
            vTaskDelay(10);
            Nop();
        } else if((sdMount == false) || (sdConfig_read == false) || (sdSchedule_read == false)) {
            vTaskDelay(1000);
        } else{
            // Error Processing
            U6_Initialize();
            vTaskDelay(100);
        }
    }
}



/*******************************************************************************
 End of File
 */
